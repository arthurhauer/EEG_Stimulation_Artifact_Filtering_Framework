function out = gen_rand_in_range( min,max )
out=(max-min)*rand()+min;
end

